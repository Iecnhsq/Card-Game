package entity;

import java.util.LinkedHashSet;
import java.util.Set;

public class Deck {

    public Set<Integer> deck = new LinkedHashSet<>();
}
