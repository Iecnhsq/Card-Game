package holders;

public class LanguageHolder {
    
}
